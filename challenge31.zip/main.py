def function_name(parameter: data_type) -> return_type:
  """Docstring"""
  # body of the function
  return expression